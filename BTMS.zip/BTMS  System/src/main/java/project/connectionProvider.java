package project;
import java.sql.*;

public class connectionProvider {
	 private static String dburl = "jdbc:mysql://localhost:3306/btms";
	    private static String dbUname = "root";
	    private static String dbPassword = "bling2001";
	    private static String dbDriver = "com.mysql.jdbc.Driver";

	    public static Connection getConnection() throws SQLException {
	        try {
	            Class.forName(dbDriver);
	            return DriverManager.getConnection(dburl, dbUname, dbPassword);
	        } catch (ClassNotFoundException e) {
	            throw new SQLException("Database driver not found.", e);
	        }
	    }

}
