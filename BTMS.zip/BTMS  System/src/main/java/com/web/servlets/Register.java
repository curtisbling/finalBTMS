package com.web.servlets;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Register")
public class Register extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Register() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String fname = request.getParameter("firstName");
        String lname = request.getParameter("lastName");
        String uname = request.getParameter("userName");
    	String email = request.getParameter("email");
        String password = request.getParameter("password");
        String tel = request.getParameter("number");
    	String idnum = request.getParameter("idNumber");
        String role = request.getParameter("role");
        String age = request.getParameter("age");
       

        member member = new member(fname, lname,uname,email,password,tel,idnum,role,age);

        RegisterDao rDao = new RegisterDao();
        boolean isRegistrationSuccessful = rDao.insert(member);

        if (isRegistrationSuccessful) {
            // Redirect to the login page on successful registration
            response.sendRedirect("login.jsp");
        } else {
            response.getWriter().println("Registration failed. Please try again.");
        }
    }
}
