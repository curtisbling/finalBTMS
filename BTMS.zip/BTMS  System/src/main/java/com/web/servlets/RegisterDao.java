package com.web.servlets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegisterDao {
    private String dburl = "jdbc:mysql://localhost:3306/btms";
    private String dbUname = "root";
    private String dbPassword = "bling2001";
    private String dbDriver = "com.mysql.cj.jdbc.Driver";

    public Connection getConnection() throws SQLException {
        try {
            Class.forName(dbDriver);
            return DriverManager.getConnection(dburl, dbUname, dbPassword);
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found.", e);
        }
    }

    public boolean insert(member member) {
        String sql = "INSERT INTO users (FirstName, LastName, Username, Email, Password, PhoneNumber, IdNumber, Role, Age) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, member.getFname());
            ps.setString(2, member.getLname());
            ps.setString(3, member.getUname());
            ps.setString(4, member.getEmail());
            ps.setString(5, member.getPass());
            ps.setString(6, member.getTel());
            ps.setString(7, member.getIdnum());
            ps.setString(8, member.getRole());
            ps.setString(9, member.getAge());

            int rowsAffected = ps.executeUpdate();

            // Check if insertion was successful
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
