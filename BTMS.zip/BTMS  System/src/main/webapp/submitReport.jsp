<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="project.connectionProvider" %>

<%
    // Retrieve form data
    int driverID = (int) session.getAttribute("userId");
    int scheduleID = Integer.parseInt(request.getParameter("scheduleId"));
    String reportType = request.getParameter("type");
    String reason = request.getParameter("reason");

    Connection con = null;
    PreparedStatement ps = null;

    try {
        // Establish database connection
        con = connectionProvider.getConnection();

        // Prepare SQL query
        String query = "INSERT INTO reports (DriverID, ScheduleID, ReportType, Reason) VALUES (?, ?, ?, ?)";
        ps = con.prepareStatement(query);
        ps.setInt(1, driverID);
        ps.setInt(2, scheduleID);
        ps.setString(3, reportType);
        ps.setString(4, reason);

        // Execute the query
        int rowsAffected = ps.executeUpdate();

        if (rowsAffected > 0) {
            // Redirect back to the driver dashboard with a success message
            response.sendRedirect("driver.jsp?success=report_submitted");
        } else {
            // Redirect back to the driver dashboard with an error message
            response.sendRedirect("driver.jsp?error=report_submission_failed");
        }
    } catch (SQLException e) {
        // Handle SQL exception
        e.printStackTrace();
        response.sendRedirect("driver.jsp?error=database_error");
    } finally {
        // Close resources
        if (ps != null) {
            try {
                ps.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
%>
