<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="project.connectionProvider" %>
<%@ page import="java.sql.*" %>
<%@ page import="java.io.*, java.util.*" %>
<%
    if ("POST".equalsIgnoreCase(request.getMethod())) {
        String userType = request.getParameter("userType");
        
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        
        try {
            connection = connectionProvider.getConnection();

            if (userType.equals("driver")) {
                // Handle inputs for driver form
                String fullName = request.getParameter("fullName");
                String email = request.getParameter("email");
                String password = request.getParameter("password");
                String phoneNumber = request.getParameter("phoneNumber");
                String license = request.getParameter("license");
                int age = Integer.parseInt(request.getParameter("age"));
                
                String insertDriverQuery = "INSERT INTO drivers (fullName, email, password, phoneNumber, license, age) VALUES (?, ?, ?, ?, ?, ?)";
                preparedStatement = connection.prepareStatement(insertDriverQuery);
                preparedStatement.setString(1, fullName);
                preparedStatement.setString(2, email);
                preparedStatement.setString(3, password);
                preparedStatement.setString(4, phoneNumber);
                preparedStatement.setString(5, license);
                preparedStatement.setInt(6, age);
                preparedStatement.executeUpdate();
                
            } else if (userType.equals("manager")) {
                // Handle inputs for terminus manager form
            	// Handle inputs for terminus manager form
            	String managerName = request.getParameter("mName");
            	String managerEmail = request.getParameter("memail");
            	String managerPassword = request.getParameter("mpassword");
            	String managerPhoneNumber = request.getParameter("mphoneNumber");
            	String managerTerminus = request.getParameter("mterminus");
            	String managerAge = request.getParameter("mage");

            	String insertManagerQuery = "INSERT INTO tmanagers (fullName, email, password, phoneNumber, terminus, age) VALUES (?, ?, ?, ?, ?, ?)";
            	preparedStatement = connection.prepareStatement(insertManagerQuery);
            	preparedStatement.setString(1, managerName);
            	preparedStatement.setString(2, managerEmail);
            	preparedStatement.setString(3, managerPassword);
            	preparedStatement.setString(4, managerPhoneNumber);
            	preparedStatement.setString(5, managerTerminus);
            	preparedStatement.setString(6, managerAge);
            	preparedStatement.executeUpdate();
            	  }

            response.sendRedirect("login.html");

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Closing resources
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
%>
