<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="project.connectionProvider" %>
<%
    // Retrieve the session ID of the logged-in driver
    String sessionID = (String) session.getAttribute("session_id");
    int driverID = -1; // Default value

    // Get the driver ID based on the session ID
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
        con = connectionProvider.getConnection();
        String driverQuery = "SELECT DriverID FROM drivers WHERE session_id = ?";
        ps = con.prepareStatement(driverQuery);
        ps.setString(1, sessionID);
        rs = ps.executeQuery();
        if (rs.next()) {
            driverID = rs.getInt("DriverID");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Retrieve revenue data for the specific driver and their bus
    if (driverID != -1) { // If valid driver ID was found
        try {
            con = connectionProvider.getConnection();
            String query = "SELECT b.BusNumber, s.SaccoName, SUM(r.amount) AS totalRevenue " +
                           "FROM bus b " +
                           "INNER JOIN revenue r ON b.BusID = r.bus_id " +
                           "INNER JOIN sacco s ON b.sacco_id = s.SaccoID " +
                           "WHERE b.DriverID = ? " +
                           "GROUP BY b.BusNumber, s.SaccoName";
            ps = con.prepareStatement(query);
            ps.setInt(1, driverID);
            rs = ps.executeQuery();
%>
<table class="revenue-list">
    <thead>
        <tr>
            <th>Bus Number</th>
            <th>Sacco Name</th>
            <th>Total Revenue</th>
        </tr>
    </thead>
    <tbody>
        <% while (rs.next()) { %>
        <tr class="revenue-row">
            <td><%= rs.getString("BusNumber") %></td>
            <td><%= rs.getString("SaccoName") %></td>
            <td><%= rs.getDouble("totalRevenue") %></td>
        </tr>
        <% } %>
    </tbody>
</table>
<%
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    } else {
        // Handle case where no valid driver ID was found
        out.println("No revenue data found for the logged-in driver.");
    }
%>
