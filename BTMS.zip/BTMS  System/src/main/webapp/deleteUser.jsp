<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="project.connectionProvider" %>
<%
String message = "";
String driverID = request.getParameter("driverID");

if (driverID != null && !driverID.isEmpty()) {
    try {
        Connection con = connectionProvider.getConnection();

        // Check if the driverID exists in related tables
        String checkSql = "SELECT COUNT(*) AS count FROM schedules WHERE driverID = ?";
        PreparedStatement checkStatement = con.prepareStatement(checkSql);
        checkStatement.setString(1, driverID);
        ResultSet checkResult = checkStatement.executeQuery();
        checkResult.next();
        int scheduleCount = checkResult.getInt("count");
        checkResult.close();
        checkStatement.close();

        if (scheduleCount > 0) {
            message = "Cannot delete driver. Driver is associated with schedules.";
        } else {
            // Proceed with deletion if no associated records found
            String deleteSql = "DELETE FROM drivers WHERE driverID = ?";
            PreparedStatement ps = con.prepareStatement(deleteSql);
            ps.setString(1, driverID);
            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                message = "Driver deleted successfully.";
            } else {
                message = "Failed to delete driver.";
            }

            ps.close();
        }

        con.close();
    } catch (SQLException e) {
        out.println("Error: " + e.getMessage());
    }
} else {
    message = "Driver ID is missing.";
}
out.println("<script>alert('" + message + "');</script>");
%>

<script>
    // Redirect back to the same page after a short delay
    setTimeout(function() {
        window.location.href = 'adminHome.jsp';
    }, 2000);
</script>
