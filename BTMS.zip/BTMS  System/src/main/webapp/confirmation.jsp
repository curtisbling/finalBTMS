<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terminus Manager Dashboard</title>
    <link rel="stylesheet" href="tmanager.css">
</head>
<body>
    <div class="sidebar">
        <h2>Terminus Manager</h2>
        <nav>
            <a href="#" onclick="showSection('dashboard')">Dashboard</a>
            <a href="#" onclick="showSection('registerBus')">Register Bus</a>
            <a href="#" onclick="showSection('registeredbuses')">Schedule Bus</a>
            <a href="#">Notifications</a>
        </nav>
    </div>

    <div class="main-content">
        <header>
            <div class="search-bar">
                <form method="GET">
        <input type="text" name="searchTerm" placeholder="Enter search term">
    </form>
            </div>
            <div class="user-profile">
                <img src="img/admin.png" alt="avatar">
            </div>
        </header>

        <main>
        
    <section id="dashboard" class="manager">
            <h3>Dashboard</h3>

            <div class="statistics">
                <div class="stat-card">
                    <div class="icon bg-indigo">
                        <img src="img/bus.png" alt="Bus Icon">
                    </div>
                    <div class="stat-info">
                        <h4>50</h4>
                        <p>Registered Buses</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="icon bg-green">
                       <img src="img/route.png" alt="Bus Icon">
                    </div>
                    <div class="stat-info">
                        <h4>30</h4>
                        <p>Routes Assigned</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="icon bg-yellow">
                        <img src="img/calendar.png" alt="Bus Icon">
                    </div>
                    <div class="stat-info">
                        <h4>20</h4>
                        <p>Schedules Created</p>
                    </div>
                </div>
            </div>
   </section>
   
   </main>


</body>
</html>