<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="project.connectionProvider" %>
<%@ page import="java.sql.*" %>
<%@ page import="java.io.*, java.util.*" %>
<%
    String driverIDParam = request.getParameter("driverID");
    int driverID = 0;
    if (driverIDParam != null && !driverIDParam.isEmpty()) {
        driverID = Integer.parseInt(driverIDParam);
    }

    String fullName = request.getParameter("fullName");
    String email = request.getParameter("email");
    String password = request.getParameter("password");
    String phoneNumber = request.getParameter("phoneNumber");
    String license = request.getParameter("license");
    
    int age = 0;
    String ageParam = request.getParameter("age");
    if (ageParam != null && !ageParam.isEmpty()) {
        age = Integer.parseInt(ageParam);
    }

    Connection connection = null;
    PreparedStatement preparedStatement = null;

    try {
        connection = connectionProvider.getConnection();
        String query = "UPDATE drivers SET fullName=?, email=?, password=?, phoneNumber=?, license=?, age=? WHERE driverID=?";
        preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, fullName);
        preparedStatement.setString(2, email);
        preparedStatement.setString(3, password);
        preparedStatement.setString(4, phoneNumber);
        preparedStatement.setString(5, license);
        preparedStatement.setInt(6, age);
        preparedStatement.setInt(7, driverID);
        preparedStatement.executeUpdate();

        response.sendRedirect("adminHome.jsp?success=true");
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        // Closing resources
        if (preparedStatement != null) {
            try {
                preparedStatement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
%>
