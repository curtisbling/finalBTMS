<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="project.connectionProvider" %>
<%@ page import="java.sql.*" %>
<%@ page import="java.io.*, java.util.*" %>
<%
    int scheduleId = Integer.parseInt(request.getParameter("ScheduleID"));

    Connection connection = null;
    PreparedStatement preparedStatement = null;

    try {
        connection = connectionProvider.getConnection();

        // Delete the schedule from the Schedules table based on the schedule ID
        String deleteQuery = "DELETE FROM schedules WHERE ScheduleID = ?";
        preparedStatement = connection.prepareStatement(deleteQuery);
        preparedStatement.setInt(1, scheduleId);
        int rowsAffected = preparedStatement.executeUpdate();

        if (rowsAffected > 0) {
            response.sendRedirect("tmanagerHome.jsp");
        } else {
            out.println("<script>alert('Failed to delete schedule. Please try again.'); window.location.href = 'tmanagerHome.jsp';</script>");
        }

    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        // Closing resources
        if (preparedStatement != null) {
            try {
                preparedStatement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
%>
