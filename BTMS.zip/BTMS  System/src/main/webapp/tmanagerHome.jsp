<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terminus Manager Dashboard</title>
    <link rel="stylesheet" href="tmanager.css">
</head>
<body>
    <div class="sidebar">
        <h2>Terminus Manager</h2>
        <nav>
            <a href="#" onclick="showSection('dashboard')">Dashboard</a>
            <a href="#" onclick="showSection('registeredbuses')">Registered Buses</a>
             <a href="#" onclick="showSection('revenue')">Revenue</a>
            <a href="#" onclick="showSection('notifications')">Notifications</a>
            <a href="logout.jsp">Logout</a>
            
        </nav>
    </div>

    <div class="main-content">
        <header>
            <div class="search-bar">
                <form method="GET">
        <input type="text" name="searchTerm" placeholder="Enter search term">
    </form>
            </div>
            <div class="user-profile">
                <img src="img/admin.png" alt="avatar">
            </div>
        </header>

        <main>
        
    <section id="dashboard" class="manager">
            <h3>Dashboard</h3>

            <div class="statistics">
                <div class="stat-card">
                    <div class="icon bg-indigo">
                        <img src="img/bus.png" alt="Bus Icon">
                    </div>
                    <div class="stat-info">
                        <h4>50</h4>
                        <p>Registered Buses</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="icon bg-green">
                       <img src="img/route.png" alt="Bus Icon">
                    </div>
                    <div class="stat-info">
                        <h4>30</h4>
                        <p>Routes Assigned</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="icon bg-yellow">
                        <img src="img/calendar.png" alt="Bus Icon">
                    </div>
                    <div class="stat-info">
                        <h4>20</h4>
                        <p>Schedules Created</p>
                    </div>
                </div>
            </div> <br>
            
        <div class="table-container">
    <button class="add-button" onclick="showSection('registeredbuses')">Add New Schedule</button>
    <button class="add-button">Print</button><br><br><br>
<table>
    <thead>
        <tr>
            <th class="header">Bus Plate</th>
            <th class="header">Driver</th>
            <th class="header">Route</th>
            <th class="header">Departure</th>
            <th class="header">Arrival</th>
            <th class="header">Terminus</th>
            <th class="header">Status</th>
            <th class="header">Actions</th>
        </tr>
    </thead>
    <tbody>
        <%@ include file="displaySchedules.jsp" %>
    </tbody>
</table>
</div>
            
   </section>
            

<section id="registeredbuses" class="manager">
    <div class="container">
        <table id="busTable" class="custom-table">
            <thead>
                <tr>
                    <td><b>Driver</b></td>
                    <td><b>BusPlate</b></td>
                    <td><b>Capacity</b></td>
                    <td><b>Sacco</b></td>
                </tr>
            </thead>
            <tbody>
                <%@page import ="java.sql.*" %>
                <%@page import ="project.connectionProvider" %>
                <% 
                try {
                    Connection con = connectionProvider.getConnection();
                    Statement st = con.createStatement();
                    ResultSet rs = st.executeQuery("SELECT d.fullName, b.BusNumber, b.BusCapacity, b.BusSacco FROM bus b INNER JOIN drivers d ON b.DriverID = d.DriverID");
                    while (rs.next()) {
                        %>
                        <tr class="clickable-row" data-busplate="<%= rs.getString(2) %>" onclick="selectBusPlate('<%= rs.getString(2) %>')">
                            <td><%= rs.getString(1) %></td>
                            <td><%= rs.getString(2) %></td>
                            <td><%= rs.getString(3) %></td>
                            <td><%= rs.getString(4) %></td>
                        </tr>
                        <% 
                    }
                    rs.close();
                    st.close();
                    con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                } 
                %>
            </tbody>
        </table>
    </div>
</section>
            
 <section id="schedules" class="manager">
    <div class="container">
        <h1>Bus Scheduling</h1>
        <form id="scheduleForm" action="schedule.jsp" method="post">
        
            <label for="route">Bus route:</label>
            <input type="text" id="route" name="busRoute" required>
            
            <label for="departureTime">Departure Time:</label>
            <input type="time" id="departureTime" name="departureTime" required>
            
             <label for="arrivalTime">Arrival Time:</label>
            <input type="time" id="arrivalTime" name="arrivalTime" required>

            <label for="busPlate">Bus Plate:</label>
            <input type="text" id="busPlate" name="busPlate" value="<%= request.getParameter("busPlate") %>" required readonly>
            
            <label for="terminus">Terminus:</label>
            <select id="terminus" name="terminus" required>
                <option value="Railways">Railways</option>
                <option value="Rongai">Rongai</option>
                <option value="Ngong">Ngong</option>
            </select>

            <button type="submit" onclick="showSection('dashboard')">Schedule Bus</button>
        </form>
    </div>
</section>

<section id="revenue" class="manager">
 <%@ include file="revenue.jsp" %>
</section>

<section id="notifications" class="manager">
 <%@ include file="showReports.jsp" %>
</section>


 
            
        </main>
    </div>
    <script>
    //script to display sections
    function showSection(sectionId) {
        var sections = document.getElementsByClassName('manager');
        for (var i = 0; i < sections.length; i++) {
            sections[i].style.display = 'none';
        }
        document.getElementById(sectionId).style.display = 'block'; 
    }
    //display schedules when a row is clicked on the table
    document.addEventListener("DOMContentLoaded", function() {
        var rows = document.querySelectorAll(".clickable-row");
        rows.forEach(function(row) {
            row.addEventListener("click", function() {
                document.getElementById("schedules").style.display = "block";
            });
        });
    });

   
    function selectBusPlate(busPlate) {
        document.getElementById('busPlate').value = busPlate;
    }
</script>
</body>
</html>
    