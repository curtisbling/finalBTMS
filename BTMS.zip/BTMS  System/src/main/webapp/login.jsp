<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="project.connectionProvider" %>
<%@ page import="java.sql.*" %>
<%@ page import="java.io.*, java.util.*" %>
<%
    if ("POST".equalsIgnoreCase(request.getMethod())) {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        try {
            connection = connectionProvider.getConnection();
            
            // Query drivers table
            String driverQuery = "SELECT * FROM drivers WHERE email = ? AND password = ?";
            preparedStatement = connection.prepareStatement(driverQuery);
            preparedStatement.setString(1, email);
            preparedStatement.setString(2, password);
            resultSet = preparedStatement.executeQuery();
            
            if (resultSet.next()) {
                // Driver is logged in
                int driverId = resultSet.getInt("driverID");
                session.setAttribute("userId", driverId);
                session.setAttribute("userType", "driver");
                response.sendRedirect("driver.jsp");
            } else {
                // Query tmanagers table
                String managerQuery = "SELECT * FROM tmanagers WHERE email = ? AND password = ?";
                preparedStatement = connection.prepareStatement(managerQuery);
                preparedStatement.setString(1, email);
                preparedStatement.setString(2, password);
                resultSet = preparedStatement.executeQuery();
                
                if (resultSet.next()) {
                    // Transport manager is logged in
                    String managerId = resultSet.getString("managerID");
                    session.setAttribute("userId", managerId);
                    session.setAttribute("userType", "manager");
                    response.sendRedirect("tmanagerHome.jsp");
                } else {
                    out.println("Invalid username or password");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
%>
