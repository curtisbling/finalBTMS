<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Driver Dashboard</title>
    <link rel="stylesheet" href="driverpage.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <div class="container1">
        <div class="sidebar">
            <h2>Bus Driver Dashboard</h2>
            <nav>
            <a href="#" onclick="showSection('dashboard')">Dashboard</a>
            <a href="#" onclick="showSection('registerBus')">Register Bus</a>
            <a href="#" onclick="showSection('viewschedules')">Schedules</a>
            <a href="#" onclick="showSection('revenue')">My Bus Revenue</a>
            <a href="#" onclick="showSection('notification')">Notifications</a>  
            <a href="logout.jsp">logout</a>   
            </nav>
        </div>
        <div class="main-content">
            <header>
                <div class="user-profile">
                    <img src="img/chauffeur.png" alt="Driver">
                </div>
            </header>
            <h3 font: Medium >My Dashboard</h3>
            <main>
            
            <section id="dashboard" class="driver">
               <div id="driverInfo">
    <div class="card1">
        <h3>Bus Information</h3>
        <dl>
        <%@ page import="project.connectionProvider" %>
        <%@ page import="java.sql.*" %>
        <%@ page import="java.io.*, java.util.*" %>
        
            <% 
            Connection connection = null;
            PreparedStatement preparedStatement = null;
            ResultSet resultSet = null;

            try {
                // Get the driver's ID from the session
                int driverID = (int) session.getAttribute("userId");

                connection = connectionProvider.getConnection();
                // Retrieve bus information based on the driver's ID
                String query = "SELECT b.BusID, b.BusNumber, b.BusSacco FROM bus b WHERE b.DriverID = ?";
                preparedStatement = connection.prepareStatement(query);
                preparedStatement.setInt(1, driverID);
                resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    String busNumber = resultSet.getString("BusID");
                    String licensePlate = resultSet.getString("BusNumber");
                    String busSacco = resultSet.getString("BusSacco");

                    %>
                    <div>
                        <dt>Bus Number</dt>
                        <dd><%= busNumber %></dd>
                    </div>
                    <div>
                        <dt>License Plate</dt>
                        <dd><%= licensePlate %></dd>
                    </div>
                    <div>
                        <dt>Bus Sacco</dt>
                        <dd><%= busSacco %></dd>
                    </div>
                    <%
                } else {
                    // Handle case when bus information is not found for the driver
                    out.println("Bus information not found for this driver.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                // Closing resources
                if (resultSet != null) {
                    try {
                        resultSet.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                if (preparedStatement != null) {
                    try {
                        preparedStatement.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
            %>
        </dl>
    </div>
    <br>
    <br>
</div>
               
                
                <div id="driverSchedule">
    <div class="card1">
        <h3>Today's Schedule</h3>
        <dl>
            <% 

            try {
                // Get the driver's ID from the session
                int driverID = (int) session.getAttribute("userId");

                connection = connectionProvider.getConnection();
                // Retrieve schedule information based on the driver's ID
                String query = "SELECT DepartureTime, BusRoute, ArrivalTime FROM schedules WHERE DriverID = ? AND DATE(DepartureTime) = CURDATE()"; // Adjust the query to fit your database schema
                preparedStatement = connection.prepareStatement(query);
                preparedStatement.setInt(1, driverID);
                resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    String departureTime = resultSet.getString("DepartureTime");
                    String route = resultSet.getString("BusRoute");
                    String estimatedArrival = resultSet.getString("ArrivalTime");

                    %>
                    <div>
                        <dt>Departure Time</dt>
                        <dd><%= departureTime %></dd>
                    </div>
                    <div>
                        <dt>Route</dt>
                        <dd><%= route %></dd>
                    </div>
                    <div>
                        <dt>Estimated Arrival</dt>
                        <dd><%= estimatedArrival %></dd>
                    </div>
                    <%
                } else {
                    // Handle case when schedule information is not found for the driver
                    out.println("Schedule information not found for today.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                // Closing resources
                if (resultSet != null) {
                    try {
                        resultSet.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                if (preparedStatement != null) {
                    try {
                        preparedStatement.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
            %>
        </dl>
    </div>
</div>              
                </section>
              
                
                  <section id="registerBus" class="driver">
    <div class="container">
        <h1>Bus Registration</h1>
        <form id="registrationForm" action="busReg.jsp" method="post">
            <label for="busPlate">Bus Plate:</label>
            <input type="text" id="busPlate" name="busPlate" required pattern="[A-Za-z0-9]{1,10}"
                title="Only letters, numbers, and spaces, maximum 10 characters">

            <label for="capacity">Capacity:</label>
            <input type="number" id="capacity" name="capacity" required min="1" max="100"
                title="Please enter a number between 1 and 100">

            <label for="sacco">Sacco:</label>
            <input type="text" id="sacco" name="sacco" required pattern="[A-Za-z0-9\s]{1,50}"
                title="Only letters, numbers, and spaces, maximum 50 characters">
           <button type="submit">Register Bus</button>

        </form>
    </div>
</section>

<section id="viewschedules" class="driver">
    <div class="container1">
        <div class="card1">
            <h3>Today's Schedule</h3>
            <div class="schedule-container">
                <% 
                try {
                    // Get the driver's ID from the session
                    int driverID = (int) session.getAttribute("userId");

                    connection = connectionProvider.getConnection();
                    // Retrieve schedules for the driver
                    String query = "SELECT ScheduleID, DepartureTime, BusRoute, ArrivalTime FROM schedules WHERE DriverID = ? ORDER BY DepartureTime DESC";
                    preparedStatement = connection.prepareStatement(query);
                    preparedStatement.setInt(1, driverID);
                    resultSet = preparedStatement.executeQuery();

                    while (resultSet.next()) {
                        int scheduleId = resultSet.getInt("ScheduleID");
                        String departureTime = resultSet.getString("DepartureTime");
                        String route = resultSet.getString("BusRoute");
                        String estimatedArrival = resultSet.getString("ArrivalTime");

                        %>
                        <dl class="schedule-item" onclick="showPopup(<%= scheduleId %>)">
                            <div>
                                <dt>Departure Time</dt>
                                <dd><%= departureTime %></dd>
                            </div>
                            <div>
                                <dt>Route</dt>
                                <dd><%= route %></dd>
                            </div>
                            <div>
                                <dt>Estimated Arrival</dt>
                                <dd><%= estimatedArrival %></dd>
                            </div>
                        </dl>
                        <%
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                } finally {
                    // Closing resources
                    if (resultSet != null) {
                        try {
                            resultSet.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                    if (preparedStatement != null) {
                        try {
                            preparedStatement.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                    if (connection != null) {
                        try {
                            connection.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                }
                %>
            </div>
        </div>
    </div>

    <!-- Modal popup form -->
    <div id="formPopup" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="hidePopup()">&times;</span>
            <h2>Report on Schedule</h2>
            <form id="reportForm" action="submitReport.jsp" method="post">
                <div class="form-group">
                    <label for="scheduleId">Schedule ID:</label>
                    <input type="text" id="scheduleId" name="scheduleId" readonly>
                </div>
                <div class="form-group">
                    <label for="type">Report type:</label>
                    <select id="type" name="type" required>
                        <option value="Cancellation">Cancellation</option>
                        <option value="Reschedule">Reschedule</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="reason">Reason:</label>
                    <textarea id="reason" name="reason" rows="4"></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" class="submit-button">Submit Report</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function showPopup(scheduleId) {
            document.getElementById("scheduleId").value = scheduleId;
            document.getElementById("formPopup").style.display = "block";
        }

        function hidePopup() {
            document.getElementById("formPopup").style.display = "none";
        }
    </script>
</section>


  <section id="revenue" class="driver">
    <h2>Revenue History</h2>
    <div id="historyContainer" class="history-container">
    <!-- Revenue list table -->
<table class="revenue-list">
    <thead>
        <tr>
            <th>Bus Number</th>
            <th>Total Revenue</th>
        </tr>
    </thead>
    <tbody>
            <%@ include file="driverRevenue.jsp" %>
    </tbody>
</table>
    
        </div>
</section>

<section id="notification" class="driver">
    <div id="notifications">
                  <%= request.getSession().getAttribute("notificationMessage") %>
    </div>
</section>



<script>
    function showSection(sectionId) {
        var sections = document.getElementsByClassName('driver');
        for (var i = 0; i < sections.length; i++) {
            sections[i].style.display = 'none';
        }
        document.getElementById(sectionId).style.display = 'block'; 
    }
    

</script>

</body>
</html>
