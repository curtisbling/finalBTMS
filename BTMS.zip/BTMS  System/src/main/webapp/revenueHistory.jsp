<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="project.connectionProvider" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Revenue History</title>
    <!-- Include Chart.js library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        canvas {
            max-width: 600px;
            max-height: 400px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <h2>Revenue History</h2>
    <canvas id="revenueChart"></canvas>

    <%
    // Initialize arrays to store dates and corresponding revenue amounts
    String[] dates = new String[3];
    double[] amounts = new double[3];
    
    // Fetch revenue data from the database
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
        con = connectionProvider.getConnection();
        String query = "SELECT revenue_date, amount FROM revenue WHERE DATEDIFF(CURDATE(), revenue_date) <= 3 ORDER BY revenue_date ASC"; // Fetch data for the last 3 days
        ps = con.prepareStatement(query);
        rs = ps.executeQuery();

        // Iterate through the result set and populate the arrays
        int index = 0;
        while (rs.next() && index < 3) {
            String date = rs.getString("revenue_date");
            if (date != null && !date.isEmpty()) {
                dates[index] = date;
                amounts[index] = rs.getDouble("amount");
                index++;
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    %>

    <!-- Script to initialize and render the line chart -->
    <script>
    var ctx = document.getElementById('revenueChart').getContext('2d');
    var revenueChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [<% for (int i = 0; i < 3; i++) { if (dates[i] != null) { %> "<%= dates[i] %>", <% } } %>],
            datasets: [{
                label: 'Revenue',
                data: [<% for (int i = 0; i < 3; i++) { if (dates[i] != null) { %> <%= amounts[i] %>, <% } } %>],
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });
    </script>
</body>
</html>
