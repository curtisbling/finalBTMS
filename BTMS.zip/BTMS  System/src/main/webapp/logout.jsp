<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="javax.servlet.http.HttpSession" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Logout</title>
    <style>
        /* Center align content */
        body, html {
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .progress-bar {
            width: 50%;
            margin: auto;
            text-align: center;
        }
        .progress-bar div {
            background-color: #4CAF50;
            width: 0%;
            height: 30px;
        }
    </style>
</head>
<body>
    <div class="progress-bar">
        <h1>Logging out...</h1>
        <div id="progress"></div>
    </div>

    <%
        // Invalidate the session
        HttpSession userSession = request.getSession(false);
        if (userSession != null) {
            userSession.invalidate();
        }
        // Redirect to the index page or any other page after logout
        response.setHeader("Refresh", "3; URL=index.html"); // Redirect after 3 seconds
    %>

    <script>
        // Simulate logout progress
        var progress = 0;
        var interval = setInterval(function() {
            progress += 5; // Increment progress by 5%
            document.getElementById("progress").style.width = progress + "%";
            if (progress >= 100) {
                clearInterval(interval);
            }
        }, 200); // Adjust interval duration as needed
    </script>
</body>
</html>
