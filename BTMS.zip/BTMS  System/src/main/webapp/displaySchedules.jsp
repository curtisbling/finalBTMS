<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="project.connectionProvider" %>
<%@ page import="java.sql.*" %>
<%@ page import="java.io.*, java.util.*" %>
<%
    Connection connection = null;
    Statement statement = null;
    ResultSet resultSet = null;

    try {
        connection = connectionProvider.getConnection();
        statement = connection.createStatement();
        resultSet = statement.executeQuery("SELECT s.ScheduleID, s.BusPlate, d.fullName, s.BusRoute, s.DepartureTime, s.ArrivalTime, s.Terminus FROM schedules s INNER JOIN drivers d ON s.DriverID = d.DriverID");

        while(resultSet.next()) {
        	int ScheduleID= resultSet.getInt("ScheduleID");
            String busPlate = resultSet.getString("BusPlate");
            String driverName = resultSet.getString("fullName");
            String busRoute = resultSet.getString("BusRoute");
            String departureTime = resultSet.getString("DepartureTime");
            String arrivalTime = resultSet.getString("ArrivalTime");
            String currentTerminus = resultSet.getString("Terminus");

            out.println("<tr>");
            out.println("<td contenteditable='true'>" + busPlate + "</td>");
            out.println("<td contenteditable='true'>" + driverName + "</td>");
            out.println("<td contenteditable='true'>" + busRoute + "</td>");
            out.println("<td contenteditable='true'>" + departureTime + "</td>");
            out.println("<td contenteditable='true'>" + arrivalTime + "</td>");
            out.println("<td contenteditable='true'>" + currentTerminus + "</td>");
            out.println("<td><button onclick='sendNotification(\"" + busPlate + "\", this)' class='alert-button'>Alert</button></td>");
            out.println("<td>");
            out.println("<a href='updateSchedule.jsp?busPlate=" + busPlate + "'><img src='img/update.png' style='width:20px' /></a>");
            out.println("<a href='deleteSchedule.jsp?ScheduleID=" + ScheduleID + "'><img src='img/delete.png' style='width:20px'/></a>");
            out.println("</td>");
            out.println("</tr>");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        // Closing resources
        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
%>
<script>
function sendNotification(busPlate, button) {
    // Create a hidden form element
    var form = document.createElement('form');
    form.method = 'GET';
    form.action = 'sendNotification.jsp';

    // Create an input field to hold the busPlate value
    var input = document.createElement('input');
    input.type = 'hidden';
    input.name = 'busPlate';
    input.value = busPlate;

    // Add the input field to the form
    form.appendChild(input);

    // Submit the form
    document.body.appendChild(form);
    form.submit();

    // Change button text to indicate driver has been alerted
    button.innerText = "Alerted";
    button.disabled = true; // Disable the button after alerting the driver
}

</script>



