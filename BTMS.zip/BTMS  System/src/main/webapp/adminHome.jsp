<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin Home</title>
<link rel="stylesheet" href="adminHome.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<header>
    <h1>Welcome Admin</h1><br>
    <nav>
        <ul>
            <li><a href="#" onclick="showSection('dashboard')">Dashboard</a></li>
            <li><a href="#" onclick="showSection('useradd')">Add New Users</a></li>
            <li><a href="#" onclick="showSection('usermanagement')">Registered Users</a></li>     
            <li><a href="#">Reports</a></li>
            <li><a href="#">Settings</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ul>
    </nav>
</header>
<main>
    
        <section id="dashboard" class="admin">
            <section class="dashboard">
                <div class="dashboard-box">
                    <h3>Users</h3>
                    <img src="img/users.png" alt="User Icon">
                    <p>Total Users: 100</p>
                </div>
            
                <div class="dashboard-box">
                    <h3>Buses</h3>
                    <img src="img/bus.png" alt="Bus Icon">
                    <p>Total Buses: 50</p>
                </div>
               
                <div class="dashboard-box">
                    <h3>Terminus</h3>
                    <img src="img/bus-station.png" alt="Terminus Icon">
                    <p>Total Terminus: 10</p>
                </div>

                <div class="dashboard-box">
                    <h3>Revenues</h3>
                    <img src="img/profit-growth.png" alt="Revenue Icon">
                    <p>Total Revenue: KES 100k+</p>
                </div>
            </section>
            
            <div class="container1">
                <section class="graph">
                    <h2>Passenger Traffic</h2>
                    <canvas id="passengerTrafficChart"></canvas>
                </section>
                
                <section class="graph">
                    <h2>Sacco Revenue Comparison</h2>
                    <canvas id="revenueComparisonChart"></canvas>
                </section>
            </div>
        </section>

        
        
        <section id="useradd" class="admin">
           <div class="form-container">
        <div class="form-selector">
            <button class="selector-button" onclick="showForm('driver')">Driver Form</button>
            <button class="selector-button" onclick="showForm('manager')">Terminus Manager Form</button>
        </div>

        <form id="driver-form" method="post" class="form" action="registration.jsp" style="display: none;" onsubmit="return validateForm()">
    <h2>Driver Registration</h2>
    <input type="hidden" name="userType" value="driver">
    <input type="text" name="fullName" placeholder="Full Name" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="tel" name="phoneNumber" placeholder="Phone Number" pattern="[0-9]{10}" required>
    <input type="text" name="license" placeholder="License Number" required>
    <input type="number" name="age" placeholder="Age" min="19" required>
    <button type="submit">Register</button>
</form>


        <form id="manager-form" method="post" class="form" action="registration.jsp" style="display: none;" onsubmit="return validateForm()">
            <h2>Terminus Manager Registration</h2>
		   <input type="hidden" name="userType" value="manager">
           <input type="text" name="mName" placeholder="Full Name" required>
           <input type="email" name="memail" placeholder="Email" required>
           <input type="password" name="mpassword" placeholder="Password" required>
           <input type="tel" name="mphoneNumber" placeholder="Phone Number" pattern="[0-9]{10}" required>
           <input type="text" name="mterminus" placeholder="terminusName" required>
           <input type="number" name="mage" placeholder="Age" min="19" required>
           <button type="submit">Register></button>
        </form>
    </div>
</section>

<section id="usermanagement" class="admin">
    <div class="users">
    
     <% if (request.getAttribute("updateMessage") != null) { %>
        <div style="color: green;"><%= request.getAttribute("updateMessage") %></div>
    <% } %>
        <h1>Drivers</h1>
        <table id="drivers">
            <thead>
                <tr>
                    <th class="header">Driver ID</th>
                    <th class="header">Driver Name</th>
                    <th class="header">Email</th>
                    <th class="header">Password</th>
                    <th class="header">Telephone</th>
                    <th class="header">License</th>
                    <th class="header">Age</th>
                    <th class="header">Actions</th>
                </tr>
            </thead>
            <tbody>
                <%@ include file="displayUsers.jsp" %>
            </tbody>
        </table>
        <br><br><br>
        <h1>Terminus Managers</h1>
        <table id="managers">
            <thead>
                <tr>
                    <th class="header">Manager ID</th>
                    <th class="header">Manager Name</th>
                    <th class="header">Email</th>
                    <th class="header">Password</th>
                    <th class="header">Telephone</th>
                    <th class="header">Terminus</th>
                    <th class="header">Age</th>
                    <th class="header">Actions</th>
                </tr>
            </thead>
            <tbody>
                <%@ include file="displayManagers.jsp" %>
            </tbody>
        </table>
    </div>
</section>


    
</main>
<footer>
    <p>&copy; 2023 Bus Terminus Management System</p>
</footer>

<script>
    var passengerTrafficChart = new Chart(document.getElementById('passengerTrafficChart').getContext('2d'), {
        type: 'bar',
        data: {
            labels: ['Morning', 'Afternoon', 'Evening'],
            datasets: [{
                label: 'Passenger Traffic',
                data: [800, 300, 600],
                backgroundColor: ['#ff6384', '#36a2eb', '#ffce56']
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });
    
    var revenueComparisonChart = new Chart(document.getElementById('revenueComparisonChart').getContext('2d'), {
        type: 'pie',
        data: {
            labels: ['Orokise', 'Snowball', 'Transline'],
            datasets: [{
                data: [3000, 4000, 5000],
                backgroundColor: ['#ff6384', '#36a2eb', '#ffce56']
            }]
        }
    });
    
    function showSection(sectionId) {
        var sections = document.getElementsByClassName('admin');
        for (var i = 0; i < sections.length; i++) {
            sections[i].style.display = 'none';
        }
        document.getElementById(sectionId).style.display = 'block'; 
    }
    
    function showForm(formType) {
        var driverForm = document.getElementById('driver-form');
        var managerForm = document.getElementById('manager-form');

        if (formType === 'driver') {
            driverForm.style.display = 'block';
            managerForm.style.display = 'none';
        } else if (formType === 'manager') {
            driverForm.style.display = 'none';
            managerForm.style.display = 'block';
        }
    }
    

   function validateForm() {
       var email = document.getElementById("email").value;
       var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

       if (!emailPattern.test(email)) {
         alert("Please enter a valid email address");
         return false;
         }
       if (age <= 18) {
       alert("Age must be greater than 18");
       return false;
       }
    }
   
   //display users
    function showlist(userType) {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("userTable").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "displayUsers.jsp?userType=" + userType, true);
        xhttp.send();
    }
</script>


</body>
</html>
    