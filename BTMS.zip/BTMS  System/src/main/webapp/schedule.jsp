<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="project.connectionProvider" %>
<%@ page import="java.sql.*" %>
<%@ page import="java.io.*, java.util.*" %>
<%
    if ("POST".equalsIgnoreCase(request.getMethod())) {
    	 String busRoute = request.getParameter("busRoute");
        String departureTimeStr = request.getParameter("departureTime");
        String arrivalTimeStr = request.getParameter("arrivalTime");
        String busPlate = request.getParameter("busPlate");
        String currentTerminus = request.getParameter("terminus");

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = connectionProvider.getConnection();

            // Get DriverID from bus table based on BusPlate
            String driverIdQuery = "SELECT d.DriverID FROM drivers d INNER JOIN bus b ON d.DriverID = b.DriverID WHERE b.BusNumber = ?";
            preparedStatement = connection.prepareStatement(driverIdQuery);
            preparedStatement.setString(1, busPlate);
            resultSet = preparedStatement.executeQuery();

            int driverId = 0;
            if(resultSet.next()) {
                driverId = resultSet.getInt("DriverID");
            }

            // Get BusID from bus table based on BusPlate
            String busIdQuery = "SELECT BusID FROM bus WHERE BusNumber = ?";
            preparedStatement.close(); // Close previous prepared statement
            preparedStatement = connection.prepareStatement(busIdQuery);
            preparedStatement.setString(1, busPlate);
            resultSet = preparedStatement.executeQuery();

            int busId = 0;
            if(resultSet.next()) {
                busId = resultSet.getInt("BusID");
            }

            // Inserting schedule details into the Schedules table
            String insertQuery = "INSERT INTO schedules (DepartureTime, ArrivalTime, BusPlate, BusRoute, Terminus, BusID, DriverID) VALUES (STR_TO_DATE(?, '%H:%i'), STR_TO_DATE(?, '%H:%i'), ?, ?, ?, ?, ?)";
            preparedStatement.close(); 
            preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setString(1, departureTimeStr);
            preparedStatement.setString(2, arrivalTimeStr);
            preparedStatement.setString(3, busPlate);
            preparedStatement.setString(4, busRoute);
            preparedStatement.setString(5, currentTerminus);
            preparedStatement.setInt(6, busId);          
            preparedStatement.setInt(7, driverId);
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Closing resources
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
%>
