<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="project.connectionProvider" %>
<%
    // Retrieve list of buses and their total revenue from the database
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
        con = connectionProvider.getConnection();
        String query = "SELECT b.BusID, b.BusNumber, SUM(r.amount) AS totalRevenue " +
                       "FROM bus b LEFT JOIN revenue r ON b.BusID = r.bus_id " +
                       "GROUP BY b.BusID, b.BusNumber";
        ps = con.prepareStatement(query);
        rs = ps.executeQuery();
%>
<table class="revenue-list">
    <thead>
        <tr>
            <th>Bus Number</th>
            <th>Total Revenue</th>
            <th>View Statistics</th>
        </tr>
    </thead>
    <tbody>
        <% while (rs.next()) { %>
        <tr class="revenue-row">
            <td><%= rs.getString("BusNumber") %></td>
            <td><%= rs.getDouble("totalRevenue") %></td>
            <td><a href="revenueHistory.jsp?busId=<%= rs.getInt("BusID") %>">View</a></td>
        </tr>
        <% } %>
    </tbody>
</table>
<%
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
%>
