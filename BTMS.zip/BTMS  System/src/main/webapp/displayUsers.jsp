<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="project.connectionProvider" %>
<%@ page import="java.sql.*" %>
<%@ page import="java.io.*, java.util.*" %>
<%
    Connection connection = null;
    Statement statement = null;
    ResultSet resultSet = null;

    try {
        connection = connectionProvider.getConnection();
        statement = connection.createStatement();
        resultSet = statement.executeQuery("SELECT driverID, fullName, email, password, phoneNumber, license, age FROM drivers");

        while(resultSet.next()) {
            int driverID = resultSet.getInt("driverID");
            String driverName = resultSet.getString("fullName");
            String email = resultSet.getString("email");
            String password = resultSet.getString("password");
            String phone = resultSet.getString("phoneNumber");
            String license = resultSet.getString("license");
            int age = resultSet.getInt("age");

            out.println("<tr>");
            out.println("<form action='updateUser.jsp' method='post'>");
            out.println("<input type='hidden' name='driverID' value='" + driverID + "'>");
            out.println("<input type='hidden' name='action' value='update'>"); // Specify action type as update
            out.println("<td>" + driverID + "</td>");
            out.println("<td contenteditable='true'><input type='text' name='fullName' value='" + driverName + "'></td>");
            out.println("<td contenteditable='true'><input type='email' name='email' value='" + email + "'></td>");
            out.println("<td contenteditable='true'><input type='password' name='password' value='" + password + "'></td>");
            out.println("<td contenteditable='true'><input type='text' name='phoneNumber' value='" + phone + "'></td>");
            out.println("<td contenteditable='true'><input type='text' name='license' value='" + license + "'></td>");
            out.println("<td contenteditable='true'><input type='number' name='age' value='" + age + "'></td>");
            out.println("<td>");
            out.println("<button type='submit'><img src='img/update.png' style='width:20px' /></button>");
            out.println("</td>");
            out.println("</form>");
            out.println("<form action='deleteUser.jsp' method='post'>"); // Form for delete operation
            out.println("<input type='hidden' name='driverID' value='" + driverID + "'>");
            out.println("<input type='hidden' name='action' value='delete'>"); // Specify action type as delete
            out.println("<td>");
            out.println("<button type='submit'><img src='img/delete.png' style='width:20px' /></button>");
            out.println("</td>");
            out.println("</form>");
            out.println("</tr>");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        // Closing resources
        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
%>
