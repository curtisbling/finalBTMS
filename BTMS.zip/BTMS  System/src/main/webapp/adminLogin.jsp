<%@ page import="java.util.Map" %>
<%@ page import="java.util.HashMap" %>

<%
    String expectedUsername = "admin";
    String expectedPassword = "bling2001";

    String enteredUsername = request.getParameter("username");
    String enteredPassword = request.getParameter("password");

    if(enteredUsername.equalsIgnoreCase("admin") && enteredPassword.equalsIgnoreCase("bling2001"))
    {
    	response.sendRedirect("adminHome.jsp");
    }
    else
    	response.sendRedirect("errorAdminLogin.html");
%>
