<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="project.connectionProvider" %>
<%
    // Retrieve form data
    String busNumber = request.getParameter("busNumber");
    double amountCollected = Double.parseDouble(request.getParameter("amountCollected"));
    String revenueDate = request.getParameter("date");

    // Get the bus ID based on the bus number
    int busID = -1; // Default value
    int saccoID = -1; // Default value
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    try {
        con = connectionProvider.getConnection();
        String busQuery = "SELECT BusID, sacco_id FROM bus WHERE BusNumber = ?";
        ps = con.prepareStatement(busQuery);
        ps.setString(1, busNumber);
        rs = ps.executeQuery();
        if (rs.next()) {
            busID = rs.getInt("BusID");
            saccoID = rs.getInt("sacco_id");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Insert revenue data into the database
    if (busID != -1 && saccoID != -1) { // If valid bus ID and sacco ID were found
        try {
            con = connectionProvider.getConnection();
            String insertQuery = "INSERT INTO revenue (bus_id, amount, revenue_date, sacco_id) VALUES (?, ?, ?, ?)";
            ps = con.prepareStatement(insertQuery);
            ps.setInt(1, busID);
            ps.setDouble(2, amountCollected); // Corrected line
            ps.setString(3, revenueDate);
            ps.setInt(4, saccoID);
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                out.println("<script>alert('Revenue remitted successfully!'); window.location.href = 'revenue.jsp#history-section';</script>");
            } else {
                out.println("<script>alert('Failed to remit revenue. Please try again.');</script>");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    } else {
        out.println("<script>alert('Invalid bus number. Please provide a valid bus number.');</script>");
    }
%>
