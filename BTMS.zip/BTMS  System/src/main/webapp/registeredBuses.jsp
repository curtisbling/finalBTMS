<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="project.connectionProvider" %>
<%@ page import="java.io.*, java.util.*" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>User ID</title>
</head>
<body>
    <%-- Retrieve user ID from session --%>
    <% int userId = (int) session.getAttribute("userId"); %>
    
    <%-- Display user ID --%>
    <h1>User ID: <%= userId %></h1>
</body>
</html>
