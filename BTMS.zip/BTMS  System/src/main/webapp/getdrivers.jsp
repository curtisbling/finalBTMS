<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="project.connectionProvider" %>
<%@ page import="java.sql.*" %>
<%
    Connection connection = null;
    PreparedStatement statement = null;
    ResultSet resultSet = null;

    try {
        connection = connectionProvider.getConnection();
        String query = "SELECT user_id, FirstName FROM users";
        statement = connection.prepareStatement(query);
        resultSet = statement.executeQuery();

        // Convert result set to JSON format
        out.println("[");
        boolean first = true;
        while (resultSet.next()) {
            if (!first) out.println(",");
            out.println("{\"id\": \"" + resultSet.getString("id") + "\", \"name\": \"" + resultSet.getString("name") + "\"}");
            first = false;
        }
        out.println("]");
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        // Close resources
        if (resultSet != null) resultSet.close();
        if (statement != null) statement.close();
        if (connection != null) connection.close();
    }
%>