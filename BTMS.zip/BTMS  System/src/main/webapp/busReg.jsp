<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*, project.connectionProvider" %>
<%@ page import="java.io.*, java.util.*" %>
<%@ page session="true" %>

<%
    if ("POST".equalsIgnoreCase(request.getMethod())) {
        String busPlate = request.getParameter("busPlate");
        int capacity = Integer.parseInt(request.getParameter("capacity"));
        String saccoName = request.getParameter("sacco");

        // Retrieving driverId from session
        int driverId = (int) session.getAttribute("userId");

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        try {
            connection = connectionProvider.getConnection();

            // Retrieve sacco ID based on sacco name
            String saccoQuery = "SELECT sacco_id FROM sacco WHERE sacco_name = ?";
            preparedStatement = connection.prepareStatement(saccoQuery);
            preparedStatement.setString(1, saccoName);
            resultSet = preparedStatement.executeQuery();
            
            int saccoId = 0;
            if (resultSet.next()) {
                saccoId = resultSet.getInt("sacco_id");
            } else {
                // Handle error if sacco does not exist
                throw new SQLException("Sacco with name '" + saccoName + "' not found.");
            }

            // Inserting bus details into the Buses table
            String insertQuery = "INSERT INTO bus (BusNumber, BusCapacity, BusSacco, DriverID, sacco_id) VALUES (?, ?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setString(1, busPlate);
            preparedStatement.setInt(2, capacity);
            preparedStatement.setString(3, saccoName);
            preparedStatement.setInt(4, driverId);
            preparedStatement.setInt(5, saccoId); // Set the sacco_id parameter
            preparedStatement.executeUpdate();
            
            // Redirect to schedule.jsp after successful registration
            response.sendRedirect("schedule.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle any errors here
            out.println("Error: " + e.getMessage()); // Print the actual SQL exception message
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
%>
