<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Terminus Management System</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="revenue.css" rel="stylesheet">
</head>
<body>
    <header class="header">
        <h1>Bus Terminus Revenue Management</h1>
    </header>
    <main class="main-container">
        <section class="search-section">
            <input type="text" id="searchInput" class="search-input" placeholder="Search for a bus...">
            <button onclick="searchBus()" class="search-button">Search</button>
        </section>
        <section class="revenue-section">
            <h2>Revenue Collection</h2>
            <form id="revenueForm" action="remit.jsp">
                <label for="busNumber">Bus Number:</label>
                <input type="text" id="busNumber" name="busNumber" required>
                
                <label for="amountCollected">Amount Collected:</label>
                <input type="number" id="amountCollected" name="amountCollected" required>
                   
            <label for="dateTime">Date:</label>
           <input type="date" id="date" name="date" required>
            
                
                <button type="submit" class="submit-button">Remit Revenue</button>
            </form>
        </section>
       <section class="history-section">
    <h2>Revenue History</h2>
    <div id="historyContainer" class="history-container">
    <!-- Revenue list table -->
<table class="revenue-list">
    <thead>
        <tr>
            <th>Bus Number</th>
            <th>Total Revenue</th>
        </tr>
    </thead>
    <tbody>
            <%@ include file="revenueData.jsp" %>
    </tbody>
</table>
    
        </div>
</section>
    </main>
   <script>

</script>
</body>
</html>

