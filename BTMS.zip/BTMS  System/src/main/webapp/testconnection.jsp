<%@ page import="java.sql.Connection" %>
<%@ page import="java.sql.DriverManager" %>
<%@ page import="java.sql.SQLException" %>
<%@ page import="java.sql.PreparedStatement" %>
<%@ page import="java.sql.ResultSet" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Database Connection Test</title>
</head>
<body>
    <h1>Database Connection Test</h1>
    <% 
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    
    	try {
    	    // Loading the MySQL JDBC driver
    	    Class.forName("com.mysql.cj.jdbc.Driver");
    	    // Establishing the database connection
    	    String dburl = "jdbc:mysql://localhost:3306/btms";
    	    String dbUname = "root";
    	    String dbPassword = "bling2001";
    	    conn = DriverManager.getConnection(dburl, dbUname, dbPassword);
 
        
        // Executing a test query
        String sql = "SELECT 1";
        pstmt = conn.prepareStatement(sql);
        rs = pstmt.executeQuery();
        
        out.println("<p>Connection to database successful!</p>");
    } catch (Exception e) {
        out.println("<p>Error connecting to database: " + e.getMessage() + "</p>");
    } finally {
        // Closing resources
        try { if (rs != null) rs.close(); } catch (SQLException e) { e.printStackTrace(); }
        try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
        try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
    }
    %>
</body>
</html>
