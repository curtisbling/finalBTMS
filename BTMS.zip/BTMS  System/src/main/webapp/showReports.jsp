<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*, java.util.*" %>
<%@ page import="project.connectionProvider" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Show Reports</title>
    <style>
        /* Add your table styling here */
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .suspended {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h2>Reports</h2>
    <table>
        <thead>
            <tr>
                <th>Report ID</th>
                <th>Driver Name</th>
                <th>Report Type</th>
                <th>Report Reason</th>
                <th>Filed at:</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <% 
            try {
                Connection conn = connectionProvider.getConnection();
                String query = "SELECT r.ReportID, r.DriverID, r.ReportType, r.Reason, r.Timestamp, d.fullName FROM reports r INNER JOIN drivers d ON r.DriverID = d.driverID";
                PreparedStatement pss = conn.prepareStatement(query);
                ResultSet rss = pss.executeQuery();
                while (rss.next()) {
                    int reportId = rss.getInt("ReportID");
                    int driverId = rss.getInt("DriverID");
                    String reportType = rss.getString("ReportType");
                    String reportReason = rss.getString("Reason");
                    String driverName = rss.getString("fullName");
                    Timestamp timestamp = rss.getTimestamp("Timestamp");
            %>
            <tr id="scheduleRow_<%= reportId %>">
                <td><%= reportId %></td>
                <td><%= driverName %></td>
                <td><%= reportType %></td>
                <td><%= reportReason %></td>
                <td><%= timestamp %></td>
                <td>
                    <button type="button" onclick="suspendSchedule(<%= reportId %>)">Suspend Schedule</button>
                </td>
            </tr>
            <% 
                }
                rss.close();
                pss.close();
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            } 
            %>
        </tbody>
    </table>

    <script>
        function suspendSchedule(reportId) {
            var row = document.getElementById("scheduleRow_" + reportId);
            if (row) {
                var cell = row.cells[row.cells.length - 1]; 
                
                // Update the cell content and style
                cell.innerHTML = "Suspended";
                cell.className = "suspended"; 
            } else {
                alert("Report " + reportId + " not found.");
            }
        }
    </script>
</body>
</html>
