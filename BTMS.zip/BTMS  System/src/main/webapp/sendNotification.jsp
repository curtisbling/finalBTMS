<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="project.connectionProvider" %>
<%@ page import="java.sql.*" %>
<%@ page import="java.io.*, java.util.*" %>

<%
    // Retrieve parameters from the request
    String busPlate = request.getParameter("busPlate");

    Connection connection = null;
    PreparedStatement statement = null;
    ResultSet resultSet = null;

    try {
        connection = connectionProvider.getConnection();
        String query = "SELECT d.fullName, d.phoneNumber, s.BusRoute, s.DepartureTime FROM drivers d INNER JOIN schedules s ON d.DriverID = s.DriverID WHERE s.BusPlate = ?";
        statement = connection.prepareStatement(query);
        statement.setString(1, busPlate);
        resultSet = statement.executeQuery();

        if(resultSet.next()) {
            String driverName = resultSet.getString("fullName");
            String phoneNumber = resultSet.getString("phoneNumber");
            String busRoute = resultSet.getString("BusRoute");
            String departureTime = resultSet.getString("DepartureTime");

            // Construct the notification message
            String notificationMessage = "Dear " + driverName + ", your bus for route " + busRoute + " has been scheduled at " + departureTime;

            // Store the notification message in session attribute
            request.getSession().setAttribute("notificationMessage", notificationMessage);
        } else {
            out.println("Driver not found for bus plate: " + busPlate);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        // Closing resources
        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
%>
