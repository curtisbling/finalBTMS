<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="project.connectionProvider" %>
<%@ page import="java.sql.*" %>
<%@ page import="java.io.*, java.util.*" %>
<%
    Connection connectionManagers = null;
    Statement statementManagers = null;
    ResultSet resultSetManagers = null;

    try {
        connectionManagers = connectionProvider.getConnection();
        statementManagers = connectionManagers.createStatement();
        resultSetManagers = statementManagers.executeQuery("SELECT managerID, fullName, email, password, phoneNumber, terminus, age FROM tmanagers");

        while(resultSetManagers.next()) {
            int managerID = resultSetManagers.getInt("managerID");
            String managerName = resultSetManagers.getString("fullName");
            String email = resultSetManagers.getString("email");
            String password = resultSetManagers.getString("password");
            String phone = resultSetManagers.getString("phoneNumber");
            String terminus = resultSetManagers.getString("terminus");
            int age = resultSetManagers.getInt("age");

            out.println("<tr>");
            out.println("<td>" + managerID + "</td>");
            out.println("<td contenteditable='true'>" + managerName + "</td>");
            out.println("<td contenteditable='true'>" + email + "</td>");
            out.println("<td contenteditable='true'>" + password + "</td>");
            out.println("<td contenteditable='true'>" + phone + "</td>");
            out.println("<td contenteditable='true'>" + terminus + "</td>");
            out.println("<td contenteditable='true'>" + age + "</td>");
            out.println("<td>");       
            out.println("<a href='updateUser.jsp?managerID=" + managerID + "'><img src='img/update.png' style='width:20px' /></a>");
            out.println("<a href='deleteUser.jsp?managerID=" + managerID + "'><img src='img/delete.png' style='width:20px'/></a>");
            out.println("</td>");
            out.println("</tr>");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        // Closing resources
        if (resultSetManagers != null) {
            try {
                resultSetManagers.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (statementManagers != null) {
            try {
                statementManagers.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (connectionManagers != null) {
            try {
                connectionManagers.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
%>
